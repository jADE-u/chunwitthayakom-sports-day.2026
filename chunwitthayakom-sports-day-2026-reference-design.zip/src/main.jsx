import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { supabase, configured } from './supabase';
import { Trophy, CalendarDays, Medal, Users, LayoutDashboard, Menu, X, Search, Filter, Clock3, MapPin, Radio, LogIn, LogOut, Plus, Pencil, Trash2, Save, Newspaper, ChevronRight, Swords, Activity, ShieldCheck, RefreshCw } from 'lucide-react';
import './style.css';

const TEAMS = [
  {id:'red', color:'#f05265', name:'สีแดง', title:'อเวจีมณีรัตน์', short:'RED'},
  {id:'blue', color:'#48a9f8', name:'สีฟ้า', title:'วิมาณฟ้าชลาลัย', short:'BLUE'},
  {id:'purple', color:'#a78bfa', name:'สีม่วง', title:'นราอเมทรัตน์', short:'PURPLE'},
  {id:'yellow', color:'#f5c84c', name:'สีเหลือง', title:'บุปผาหิมพานต์', short:'YELLOW'}
];
const PROGRAM = [
  {date:'2026-11-03', label:'3 พฤศจิกายน 2569', sports:['บาสเกตบอล','วอลเลย์บอล','เซปักตะกร้อ','แบดมินตัน']},
  {date:'2026-11-04', label:'4 พฤศจิกายน 2569', sports:['ฟุตบอล','ฟุตซอล','แฮนด์บอล','เปตอง']},
  {date:'2026-11-05', label:'5 พฤศจิกายน 2569', sports:['กรีฑา','กีฬาพื้นบ้าน (ครูและนักเรียน)','ฟุตบอลรอบชิงชนะเลิศ ม.ปลาย ชายและหญิง']}
];
// Transcribed from the supplied schedule image. The image does not identify the sport/date/court/time.
const DOC_MATCHES = [
 [36,'ทีม 3 คน','สีเหลือง – สีม่วง','ม.ปลาย หญิง','คัดเลือก'],
 [37,'เดี่ยว','ผู้ชนะคู่ที่ 1 – ผู้ชนะคู่ที่ 2','ม.1 ชาย','ชิงชนะเลิศ'],
 [38,'เดี่ยว','ผู้ชนะคู่ที่ 3 – ผู้ชนะคู่ที่ 4','ม.1 หญิง','ชิงชนะเลิศ'],
 [39,'เดี่ยว','ผู้ชนะคู่ที่ 5 – ผู้ชนะคู่ที่ 6','ม.ต้น ชาย','ชิงชนะเลิศ'],
 [40,'เดี่ยว','ผู้ชนะคู่ที่ 7 – ผู้ชนะคู่ที่ 8','ม.ต้น หญิง','ชิงชนะเลิศ'],
 [41,'เดี่ยว','ผู้ชนะคู่ที่ 9 – ผู้ชนะคู่ที่ 10','ม.ปลาย ชาย','ชิงชนะเลิศ'],
 [42,'เดี่ยว','ผู้ชนะคู่ที่ 11 – ผู้ชนะคู่ที่ 12','ม.ปลาย หญิง','ชิงชนะเลิศ'],
 [43,'คู่','ผู้ชนะคู่ที่ 13 – ผู้ชนะคู่ที่ 14','ม.1 ชาย','ชิงชนะเลิศ'],
 [44,'คู่','ผู้ชนะคู่ที่ 15 – ผู้ชนะคู่ที่ 16','ม.1 หญิง','ชิงชนะเลิศ'],
 [45,'คู่','ผู้ชนะคู่ที่ 17 – ผู้ชนะคู่ที่ 18','ม.ต้น ชาย','ชิงชนะเลิศ'],
 [46,'คู่','ผู้ชนะคู่ที่ 19 – ผู้ชนะคู่ที่ 20','ม.ต้น หญิง','ชิงชนะเลิศ'],
 [47,'คู่','ผู้ชนะคู่ที่ 21 – ผู้ชนะคู่ที่ 22','ม.ปลาย ชาย','ชิงชนะเลิศ'],
 [48,'คู่','ผู้ชนะคู่ที่ 23 – ผู้ชนะคู่ที่ 24','ม.ปลาย หญิง','ชิงชนะเลิศ'],
 [49,'ทีม 3 คน','ผู้ชนะคู่ที่ 25 – ผู้ชนะคู่ที่ 26','ม.1 ชาย','ชิงชนะเลิศ'],
 [50,'ทีม 3 คน','ผู้ชนะคู่ที่ 27 – ผู้ชนะคู่ที่ 28','ม.1 หญิง','ชิงชนะเลิศ'],
 [51,'ทีม 3 คน','ผู้ชนะคู่ที่ 29 – ผู้ชนะคู่ที่ 30','ม.ต้น ชาย','ชิงชนะเลิศ'],
 [52,'ทีม 3 คน','ผู้ชนะคู่ที่ 31 – ผู้ชนะคู่ที่ 32','ม.ต้น หญิง','ชิงชนะเลิศ'],
 [53,'ทีม 3 คน','ผู้ชนะคู่ที่ 33 – ผู้ชนะคู่ที่ 34','ม.ปลาย ชาย','ชิงชนะเลิศ'],
 [54,'ทีม 3 คน','ผู้ชนะคู่ที่ 35 – ผู้ชนะคู่ที่ 36','ม.ปลาย หญิง','ชิงชนะเลิศ']
].map(([no,type,pair,grade,round])=>({id:`doc-${no}`,match_no:no,sport:'รอระบุชนิดกีฬา',event_date:null,court:null,start_time:null,match_type:type,pairing:pair,grade,round,status:'รอแข่งขัน',team_a:null,team_b:null,score_a:null,score_b:null,source:'เอกสารกำหนดการแข่งขัน'}));

const emptyStats = TEAMS.map(t=>({...t,wins:0,losses:0,championships:0,points:0}));
function App(){
 const [page,setPage]=useState('home'), [mobile,setMobile]=useState(false);
 const [matches,setMatches]=useState(DOC_MATCHES), [news,setNews]=useState([]), [session,setSession]=useState(null);
 const [loading,setLoading]=useState(configured), [dbError,setDbError]=useState(''), [toast,setToast]=useState('');
 const [filters,setFilters]=useState({day:'all',sport:'all',team:'all',query:''});
 const [modal,setModal]=useState(null);
 const admin=!!session;
 const notify=(s)=>{setToast(s);setTimeout(()=>setToast(''),3000)};
 async function refresh(){
  if(!configured){setLoading(false);return}
  setLoading(true);setDbError('');
  const [m,n]=await Promise.all([supabase.from('matches').select('*').order('match_no',{ascending:true}),supabase.from('announcements').select('*').order('created_at',{ascending:false})]);
  if(m.error)setDbError(m.error.message); else if(m.data?.length)setMatches(m.data);
  if(!n.error)setNews(n.data||[]);
  setLoading(false);
 }
 useEffect(()=>{if(!configured)return; refresh();supabase.auth.getSession().then(({data})=>setSession(data.session));const {data:{subscription}}=supabase.auth.onAuthStateChange((_e,s)=>setSession(s));const ch=supabase.channel('live-results').on('postgres_changes',{event:'*',schema:'public',table:'matches'},refresh).on('postgres_changes',{event:'*',schema:'public',table:'announcements'},refresh).subscribe();return()=>{subscription.unsubscribe();supabase.removeChannel(ch)}},[]);
 const completed=matches.filter(m=>m.status==='จบการแข่งขัน'&&m.team_a&&m.team_b&&m.score_a!==null&&m.score_b!==null);
 const leaderboard=useMemo(()=>{const rows=emptyStats.map(t=>({...t}));completed.forEach(m=>{const a=rows.find(t=>t.id===m.team_a),b=rows.find(t=>t.id===m.team_b);if(!a||!b)return;if(Number(m.score_a)>Number(m.score_b))a.wins++,b.losses++;else if(Number(m.score_b)>Number(m.score_a))b.wins++,a.losses++;});return rows.sort((a,b)=>b.wins-a.wins||a.losses-b.losses)},[matches]);
 const shown=matches.filter(m=>(filters.day==='all'||m.event_date===filters.day)&&(filters.sport==='all'||m.sport===filters.sport)&&(filters.team==='all'||m.team_a===filters.team||m.team_b===filters.team||String(m.pairing||'').includes(TEAMS.find(t=>t.id===filters.team)?.name||'!'))&&(`${m.sport} ${m.pairing} ${m.grade} ${m.match_type}`.toLowerCase().includes(filters.query.toLowerCase())));
 const nav=[['home','ภาพรวม',LayoutDashboard],['teams','คณะสี',Users],['schedule','ตารางแข่งขัน',CalendarDays],['results','ผลการแข่งขัน',Activity],['leaderboard','ตารางคะแนน',Trophy],...(admin?[['admin','จัดการระบบ',ShieldCheck]]:[])];
 const title=nav.find(n=>n[0]===page)?.[1]||'ภาพรวม';
 async function login(email,password){const {error}=await supabase.auth.signInWithPassword({email,password});if(error)notify('เข้าสู่ระบบไม่สำเร็จ: '+error.message);else{setModal(null);setPage('admin');notify('เข้าสู่ระบบสำเร็จ')}}
 async function logout(){await supabase.auth.signOut();setPage('home');notify('ออกจากระบบแล้ว')}
 async function saveMatch(form){
  const payload={...form,match_no:Number(form.match_no)||null,score_a:form.score_a===''?null:Number(form.score_a),score_b:form.score_b===''?null:Number(form.score_b)};
  const isExisting = form.id && !String(form.id).startsWith('doc-');
  if (!isExisting) delete payload.id;
  const q=isExisting?supabase.from('matches').update(payload).eq('id',form.id):supabase.from('matches').insert(payload);
  const {error}=await q;if(error)notify('บันทึกไม่สำเร็จ: '+error.message);else{notify('บันทึกการแข่งขันแล้ว');setModal(null);refresh()}
 }
 async function deleteMatch(id){if(!confirm('ยืนยันลบรายการแข่งขันนี้?'))return;const {error}=await supabase.from('matches').delete().eq('id',id);notify(error?'ลบไม่สำเร็จ: '+error.message:'ลบรายการแล้ว');refresh()}
 async function saveNews(form){const {error}=await supabase.from('announcements').insert({title:form.title,body:form.body});if(error)notify(error.message);else{notify('เพิ่มประกาศแล้ว');setModal(null);refresh()}}
 async function deleteNews(id){if(!confirm('ลบประกาศนี้?'))return;await supabase.from('announcements').delete().eq('id',id);refresh()}
 return <div className="app">
  <header className="site-header"><div className="header-inner"><button className="mobile-toggle" onClick={()=>setMobile(v=>!v)} aria-label="เปิดเมนู"><Menu size={22}/></button><button className="site-brand" onClick={()=>setPage('home')}><b>CHUNWITTHAYAKOM</b><span>SPORTS DAY 2026</span></button><nav className={`site-nav ${mobile?'mobile-open':''}`}>{[['home','หน้าแรก'],['teams','คณะสี'],['schedule','ตารางแข่งขัน'],['results','ผลการแข่งขัน'],['leaderboard','ตารางคะแนน'],...(admin?[['admin','ผู้ดูแลระบบ']]:[])].map(([id,label])=><button key={id} className={page===id?'active':''} onClick={()=>{setPage(id);setMobile(false)}}>{label}</button>)}</nav><div className="header-tools">{admin?<button className="admin-access" onClick={logout}><LogOut size={15}/> ออกจากระบบ</button>:<button className="admin-access" onClick={()=>setModal({type:'login'})}><LogIn size={15}/> แอดมิน</button>}</div></div></header>
  <main className="main">
   {dbError&&<div className="notice error">เชื่อมต่อฐานข้อมูลไม่สำเร็จ: {dbError}</div>}
   {!configured&&<div className="notice warn"><b>โหมดตัวอย่างที่ยังไม่เชื่อมฐานข้อมูล</b> — ตั้งค่า Supabase ตาม README เพื่อเปิดใช้การบันทึกถาวรและระบบแอดมิน รายการเริ่มต้นจากเอกสารจะแสดงให้ดูได้ แต่ยังไม่สามารถบันทึกผลได้</div>}
   {page==='home'&&<Home matches={matches} completed={completed} leaderboard={leaderboard} news={news} setPage={setPage}/>}
   {page==='teams'&&<Teams leaderboard={leaderboard} matches={matches}/>}
   {page==='schedule'&&<><div className="page-intro"><div><div className="eyebrow">MATCH FIXTURES</div><h1>ตารางการแข่งขัน</h1><p>กำหนดการแข่งขันระหว่างวันที่ 3–5 พฤศจิกายน 2569</p></div><span className="count-chip">{matches.length} รายการในระบบ</span></div><div className="day-strip">{PROGRAM.map(d=><button key={d.date} className={`day-card ${filters.day===d.date?'selected':''}`} onClick={()=>setFilters(f=>({...f,day:f.day===d.date?'all':d.date}))}><b>{d.label}</b><span>{d.sports.join(' · ')}</span></button>)}</div><Filters filters={filters} setFilters={setFilters} matches={matches}/><MatchList matches={shown} admin={admin} edit={m=>setModal({type:'match',item:m})} del={deleteMatch}/></>}
   {page==='results'&&<><div className="page-intro"><div><div className="eyebrow">OFFICIAL RESULTS</div><h1>ผลการแข่งขัน</h1><p>แสดงเฉพาะผลที่ผู้ดูแลระบบบันทึกและยืนยันแล้ว</p></div><span className="count-chip">{completed.length} จบการแข่งขัน</span></div>{completed.length?<MatchList matches={completed} admin={admin} edit={m=>setModal({type:'match',item:m})} del={deleteMatch}/>:<Empty icon={Medal} title="ยังไม่มีผลการแข่งขัน" desc="ผลการแข่งขันจะปรากฏที่นี่เมื่อผู้ดูแลบันทึกคะแนนจริงแล้ว"/>}</>}
   {page==='leaderboard'&&<><div className="page-intro"><div><div className="eyebrow">TEAM STANDINGS</div><h1>ตารางคะแนนคณะสี</h1><p>จัดอันดับจากจำนวนชัยชนะในการแข่งขันที่บันทึกผลแล้ว</p></div><span className="count-chip">{completed.length} ผลที่ใช้คำนวณ</span></div><div className="leaderboard">{leaderboard.map((t,i)=><div className={`leader-row ${i===0&&completed.length?'first':''}`} key={t.id}><div className="rank">{i+1}</div><div className="team-dot" style={{background:t.color}}/><div className="leader-name"><b>{t.name} — {t.title}</b><span>{t.short}</span></div><div className="leader-stat"><b>{t.wins}</b><span>ชนะ</span></div><div className="leader-stat"><b>{t.losses}</b><span>แพ้</span></div><div className="winbar"><i style={{width:`${completed.length?100*t.wins/Math.max(1,completed.length):0}%`,background:t.color}}/></div></div>)}</div><p className="footnote">* ยังไม่มีการกำหนดเกณฑ์คะแนนสะสมหรือข้อมูลแชมป์แยกประเภท จึงแสดงเฉพาะสถิติชนะ–แพ้จากผลที่ยืนยันแล้ว</p></>}
   {page==='admin'&&admin&&<Admin matches={matches} news={news} onAdd={()=>setModal({type:'match'})} onEdit={m=>setModal({type:'match',item:m})} onDelete={deleteMatch} onNews={()=>setModal({type:'news'})} onDeleteNews={deleteNews} onRefresh={refresh}/>}
   {page==='admin'&&!admin&&<Empty icon={ShieldCheck} title="สำหรับผู้ดูแลระบบเท่านั้น" desc="กรุณาเข้าสู่ระบบด้วยบัญชีผู้ดูแล"><button className="primary-btn" onClick={()=>setModal({type:'login'})}>เข้าสู่ระบบ</button></Empty>}
   <footer><span>© 2026 CHUNWITTHAYAKOM SPORTS DAY</span><span>โรงเรียนจุนวิทยาคม · พะเยา</span></footer>
  </main>
  {modal&&<Modal modal={modal} close={()=>setModal(null)} login={login} saveMatch={saveMatch} saveNews={saveNews}/>}
  {toast&&<div className="toast">{toast}</div>}
 </div>
}

function Home({matches,completed,leaderboard,news,setPage}){
 return <section className="hero hero-reference"><div className="hero-content"><div className="hero-kicker">โรงเรียนจุนวิทยาคม อ.จุน จ.พะเยา</div><h1>CHUNWITTHAYAKOM<br/><em>SPORTS DAY 2026</em></h1><p>วันที่จัดงาน: 3–5 พฤศจิกายน 2569</p><div className="hero-actions"><button className="hero-btn" onClick={()=>setPage('schedule')}>ดูตารางการแข่งขัน <ChevronRight size={17}/></button><button className="hero-secondary" onClick={()=>setPage('teams')}>รู้จักคณะสี</button></div></div></section>
}
function Stat({icon:Icon,value,label}){return <div className="stat-card"><div className="stat-icon"><Icon size={19}/></div><b>{value}</b><span>{label}</span></div>}
function Teams({leaderboard,matches}){return <><div className="page-intro"><div><div className="eyebrow">MEET THE TEAMS</div><h1>คณะสีทั้ง 4</h1><p>รวมพลัง สร้างมิตรภาพ และแข่งขันอย่างมีน้ำใจนักกีฬา</p></div></div><div className="teams-page-grid">{TEAMS.map(t=>{const s=leaderboard.find(x=>x.id===t.id);return <div className="team-detail" key={t.id} style={{'--team':t.color}}><div className="team-detail-top"><span>{t.short} TEAM</span><Trophy size={27}/></div><div className="detail-name">{t.name}</div><h2>{t.title}</h2><div className="team-detail-stats"><div><b>{s?.wins||0}</b><span>ชนะ</span></div><div><b>{s?.losses||0}</b><span>แพ้</span></div><div><b>{matches.filter(m=>m.team_a===t.id||m.team_b===t.id).length}</b><span>รายการที่ระบุทีม</span></div></div></div>})}</div></>}
function Filters({filters,setFilters,matches}){const sports=[...new Set(matches.map(m=>m.sport).filter(Boolean))];return <div className="filters"><div className="searchbox"><Search size={17}/><input placeholder="ค้นหากีฬา คู่แข่งขัน หรือระดับชั้น" value={filters.query} onChange={e=>setFilters(f=>({...f,query:e.target.value}))}/></div><select value={filters.sport} onChange={e=>setFilters(f=>({...f,sport:e.target.value}))}><option value="all">ทุกชนิดกีฬา</option>{sports.map(s=><option key={s}>{s}</option>)}</select><select value={filters.team} onChange={e=>setFilters(f=>({...f,team:e.target.value}))}><option value="all">ทุกคณะสี</option>{TEAMS.map(t=><option key={t.id} value={t.id}>{t.name} — {t.title}</option>)}</select></div>}
function MatchList({matches,admin,edit,del}){return matches.length?<div className="match-list">{matches.map(m=><div className="match-card" key={m.id}><div className="match-number">#{m.match_no||'—'}<small>{m.event_date||'ไม่ระบุวัน'}</small></div><div className="match-info"><div className="match-tags"><span>{m.sport||'รอระบุชนิดกีฬา'}</span><span>{m.match_type||'ไม่ระบุประเภท'}</span><span>{m.grade||'ไม่ระบุระดับ'}</span></div><b>{m.pairing||`${teamName(m.team_a)} พบ ${teamName(m.team_b)}`}</b><small>{m.round||'รอบไม่ระบุ'} · {m.court||'รอประกาศสนาม'} · {m.start_time||'รอประกาศเวลา'}</small></div><div className="match-result">{m.status==='จบการแข่งขัน'?<><b>{m.score_a} : {m.score_b}</b><span className="status done">จบการแข่งขัน</span></>:<span className="status pending">{m.status||'รอแข่งขัน'}</span>}</div>{admin&&<div className="match-actions"><button onClick={()=>edit(m)} title="แก้ไข"><Pencil size={16}/></button><button onClick={()=>del(m.id)} title="ลบ"><Trash2 size={16}/></button></div>}</div>)}</div>:<Empty icon={Filter} title="ไม่พบรายการแข่งขัน" desc="ลองเปลี่ยนตัวกรองหรือคำค้นหา"/>}
function teamName(id){return TEAMS.find(t=>t.id===id)?.name||'รอระบุทีม'}
function Empty({icon:Icon,title,desc,children}){return <div className="empty-state"><div><Icon size={25}/></div><h3>{title}</h3><p>{desc}</p>{children}</div>}
function Admin({matches,news,onAdd,onEdit,onDelete,onNews,onDeleteNews,onRefresh}){return <><div className="page-intro"><div><div className="eyebrow">CONTROL CENTER</div><h1>จัดการข้อมูลการแข่งขัน</h1><p>ข้อมูลที่บันทึกจะเผยแพร่ให้ผู้เข้าชมทุกคนแบบเรียลไทม์</p></div><button className="primary-btn" onClick={onAdd}><Plus size={17}/> เพิ่มการแข่งขัน</button></div><div className="admin-summary"><Stat icon={CalendarDays} value={matches.length} label="รายการแข่งขัน"/><Stat icon={Medal} value={matches.filter(m=>m.status==='จบการแข่งขัน').length} label="บันทึกผลแล้ว"/><Stat icon={Newspaper} value={news.length} label="ประกาศข่าวสาร"/></div><div className="panel admin-panel"><div className="panel-head"><h3>รายการแข่งขันทั้งหมด</h3><button className="icon-btn" onClick={onRefresh}><RefreshCw size={16}/></button></div><MatchList matches={matches} admin edit={onEdit} del={onDelete}/></div><div className="panel admin-panel"><div className="panel-head"><h3>ข่าวสารและประกาศ</h3><button className="primary-btn small" onClick={onNews}><Plus size={15}/> เพิ่มประกาศ</button></div>{news.map(n=><div className="admin-news" key={n.id}><div><b>{n.title}</b><p>{n.body}</p></div><button onClick={()=>onDeleteNews(n.id)}><Trash2 size={16}/></button></div>)}{!news.length&&<div className="quiet-empty">ยังไม่มีประกาศ</div>}</div></>}
function Modal({modal,close,login,saveMatch,saveNews}){const item=modal.item||{};const [form,setForm]=useState({...item});const set=(k,v)=>setForm(f=>({...f,[k]:v}));return <div className="modal-backdrop" onMouseDown={e=>e.target===e.currentTarget&&close()}><div className="modal"><div className="modal-head"><h3>{modal.type==='login'?'เข้าสู่ระบบผู้ดูแล':modal.type==='news'?'เพิ่มข่าวสาร':'จัดการรายการแข่งขัน'}</h3><button className="icon-btn" onClick={close}><X/></button></div>{modal.type==='login'?<form onSubmit={e=>{e.preventDefault();login(form.email,form.password)}}><label>อีเมลผู้ดูแล<input required type="email" onChange={e=>set('email',e.target.value)}/></label><label>รหัสผ่าน<input required type="password" onChange={e=>set('password',e.target.value)}/></label><button className="primary-btn full"><LogIn size={16}/> เข้าสู่ระบบ</button></form>:modal.type==='news'?<form onSubmit={e=>{e.preventDefault();saveNews(form)}}><label>หัวข้อประกาศ<input required value={form.title||''} onChange={e=>set('title',e.target.value)}/></label><label>รายละเอียด<textarea required rows="4" value={form.body||''} onChange={e=>set('body',e.target.value)}/></label><button className="primary-btn full"><Save size={16}/> บันทึกประกาศ</button></form>:<form className="match-form" onSubmit={e=>{e.preventDefault();saveMatch(form)}}><div className="form-grid"><label>เลขคู่แข่งขัน<input type="number" value={form.match_no||''} onChange={e=>set('match_no',e.target.value)}/></label><label>ชนิดกีฬา<input required value={form.sport||''} onChange={e=>set('sport',e.target.value)} placeholder="เช่น ฟุตบอล"/></label><label>วันที่แข่งขัน<input type="date" value={form.event_date||''} onChange={e=>set('event_date',e.target.value||null)}/></label><label>เวลา<input type="time" value={form.start_time||''} onChange={e=>set('start_time',e.target.value)}/></label><label>สนาม<input value={form.court||''} onChange={e=>set('court',e.target.value)}/></label><label>ประเภท<input value={form.match_type||''} onChange={e=>set('match_type',e.target.value)}/></label><label>ระดับชั้น<input value={form.grade||''} onChange={e=>set('grade',e.target.value)}/></label><label>รอบการแข่งขัน<input value={form.round||''} onChange={e=>set('round',e.target.value)}/></label><label className="wide">คู่แข่งขัน / รายละเอียด<input required value={form.pairing||''} onChange={e=>set('pairing',e.target.value)}/></label><label>ทีม A<select value={form.team_a||''} onChange={e=>set('team_a',e.target.value||null)}><option value="">ยังไม่ระบุ</option>{TEAMS.map(t=><option value={t.id} key={t.id}>{t.name} — {t.title}</option>)}</select></label><label>ทีม B<select value={form.team_b||''} onChange={e=>set('team_b',e.target.value||null)}><option value="">ยังไม่ระบุ</option>{TEAMS.map(t=><option value={t.id} key={t.id}>{t.name} — {t.title}</option>)}</select></label><label>คะแนนทีม A<input type="number" min="0" value={form.score_a??''} onChange={e=>set('score_a',e.target.value)}/></label><label>คะแนนทีม B<input type="number" min="0" value={form.score_b??''} onChange={e=>set('score_b',e.target.value)}/></label><label className="wide">สถานะ<select value={form.status||'รอแข่งขัน'} onChange={e=>set('status',e.target.value)}><option>รอแข่งขัน</option><option>กำลังแข่งขัน</option><option>จบการแข่งขัน</option><option>เลื่อนการแข่งขัน</option></select></label></div><p className="form-hint">การนับผลชนะ–แพ้จะใช้เฉพาะรายการที่เลือกทีมทั้งสองฝ่าย ใส่คะแนน และตั้งสถานะเป็น “จบการแข่งขัน”</p><button className="primary-btn full"><Save size={16}/> บันทึกข้อมูล</button></form>}</div></div>}
createRoot(document.getElementById('root')).render(<App/>);
