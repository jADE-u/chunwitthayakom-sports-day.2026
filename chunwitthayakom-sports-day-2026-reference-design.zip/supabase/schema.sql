-- Run in Supabase SQL Editor. Create an admin user in Authentication > Users first.
create extension if not exists pgcrypto;

create table if not exists public.matches (
 id uuid primary key default gen_random_uuid(),
 match_no integer,
 sport text not null,
 event_date date,
 court text,
 start_time time,
 match_type text,
 pairing text not null,
 grade text,
 round text,
 status text not null default 'รอแข่งขัน',
 team_a text check (team_a in ('red','blue','purple','yellow')),
 team_b text check (team_b in ('red','blue','purple','yellow')),
 score_a integer check (score_a is null or score_a >= 0),
 score_b integer check (score_b is null or score_b >= 0),
 source text default 'ผู้ดูแลระบบ',
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);
create table if not exists public.announcements (
 id uuid primary key default gen_random_uuid(),
 title text not null,
 body text not null,
 created_at timestamptz not null default now()
);

alter table public.matches enable row level security;
alter table public.announcements enable row level security;

drop policy if exists "Public can read matches" on public.matches;
create policy "Public can read matches" on public.matches for select using (true);
drop policy if exists "Admins manage matches" on public.matches;
create policy "Admins manage matches" on public.matches for all to authenticated using (true) with check (true);

drop policy if exists "Public can read announcements" on public.announcements;
create policy "Public can read announcements" on public.announcements for select using (true);
drop policy if exists "Admins manage announcements" on public.announcements;
create policy "Admins manage announcements" on public.announcements for all to authenticated using (true) with check (true);

-- Enable Realtime for live updates from the admin dashboard.
alter publication supabase_realtime add table public.matches;
alter publication supabase_realtime add table public.announcements;

-- Optional seed from the supplied schedule image. The image leaves date, court, time,
-- and sport blank for these rows, so those values are intentionally not invented.
insert into public.matches (match_no,sport,match_type,pairing,grade,round,status,source)
values
(36,'รอระบุชนิดกีฬา','ทีม 3 คน','สีเหลือง – สีม่วง','ม.ปลาย หญิง','คัดเลือก','รอแข่งขัน','เอกสารกำหนดการแข่งขัน'),
(37,'รอระบุชนิดกีฬา','เดี่ยว','ผู้ชนะคู่ที่ 1 – ผู้ชนะคู่ที่ 2','ม.1 ชาย','ชิงชนะเลิศ','รอแข่งขัน','เอกสารกำหนดการแข่งขัน'),
(38,'รอระบุชนิดกีฬา','เดี่ยว','ผู้ชนะคู่ที่ 3 – ผู้ชนะคู่ที่ 4','ม.1 หญิง','ชิงชนะเลิศ','รอแข่งขัน','เอกสารกำหนดการแข่งขัน'),
(39,'รอระบุชนิดกีฬา','เดี่ยว','ผู้ชนะคู่ที่ 5 – ผู้ชนะคู่ที่ 6','ม.ต้น ชาย','ชิงชนะเลิศ','รอแข่งขัน','เอกสารกำหนดการแข่งขัน'),
(40,'รอระบุชนิดกีฬา','เดี่ยว','ผู้ชนะคู่ที่ 7 – ผู้ชนะคู่ที่ 8','ม.ต้น หญิง','ชิงชนะเลิศ','รอแข่งขัน','เอกสารกำหนดการแข่งขัน'),
(41,'รอระบุชนิดกีฬา','เดี่ยว','ผู้ชนะคู่ที่ 9 – ผู้ชนะคู่ที่ 10','ม.ปลาย ชาย','ชิงชนะเลิศ','รอแข่งขัน','เอกสารกำหนดการแข่งขัน'),
(42,'รอระบุชนิดกีฬา','เดี่ยว','ผู้ชนะคู่ที่ 11 – ผู้ชนะคู่ที่ 12','ม.ปลาย หญิง','ชิงชนะเลิศ','รอแข่งขัน','เอกสารกำหนดการแข่งขัน'),
(43,'รอระบุชนิดกีฬา','คู่','ผู้ชนะคู่ที่ 13 – ผู้ชนะคู่ที่ 14','ม.1 ชาย','ชิงชนะเลิศ','รอแข่งขัน','เอกสารกำหนดการแข่งขัน'),
(44,'รอระบุชนิดกีฬา','คู่','ผู้ชนะคู่ที่ 15 – ผู้ชนะคู่ที่ 16','ม.1 หญิง','ชิงชนะเลิศ','รอแข่งขัน','เอกสารกำหนดการแข่งขัน'),
(45,'รอระบุชนิดกีฬา','คู่','ผู้ชนะคู่ที่ 17 – ผู้ชนะคู่ที่ 18','ม.ต้น ชาย','ชิงชนะเลิศ','รอแข่งขัน','เอกสารกำหนดการแข่งขัน'),
(46,'รอระบุชนิดกีฬา','คู่','ผู้ชนะคู่ที่ 19 – ผู้ชนะคู่ที่ 20','ม.ต้น หญิง','ชิงชนะเลิศ','รอแข่งขัน','เอกสารกำหนดการแข่งขัน'),
(47,'รอระบุชนิดกีฬา','คู่','ผู้ชนะคู่ที่ 21 – ผู้ชนะคู่ที่ 22','ม.ปลาย ชาย','ชิงชนะเลิศ','รอแข่งขัน','เอกสารกำหนดการแข่งขัน'),
(48,'รอระบุชนิดกีฬา','คู่','ผู้ชนะคู่ที่ 23 – ผู้ชนะคู่ที่ 24','ม.ปลาย หญิง','ชิงชนะเลิศ','รอแข่งขัน','เอกสารกำหนดการแข่งขัน'),
(49,'รอระบุชนิดกีฬา','ทีม 3 คน','ผู้ชนะคู่ที่ 25 – ผู้ชนะคู่ที่ 26','ม.1 ชาย','ชิงชนะเลิศ','รอแข่งขัน','เอกสารกำหนดการแข่งขัน'),
(50,'รอระบุชนิดกีฬา','ทีม 3 คน','ผู้ชนะคู่ที่ 27 – ผู้ชนะคู่ที่ 28','ม.1 หญิง','ชิงชนะเลิศ','รอแข่งขัน','เอกสารกำหนดการแข่งขัน'),
(51,'รอระบุชนิดกีฬา','ทีม 3 คน','ผู้ชนะคู่ที่ 29 – ผู้ชนะคู่ที่ 30','ม.ต้น ชาย','ชิงชนะเลิศ','รอแข่งขัน','เอกสารกำหนดการแข่งขัน'),
(52,'รอระบุชนิดกีฬา','ทีม 3 คน','ผู้ชนะคู่ที่ 31 – ผู้ชนะคู่ที่ 32','ม.ต้น หญิง','ชิงชนะเลิศ','รอแข่งขัน','เอกสารกำหนดการแข่งขัน'),
(53,'รอระบุชนิดกีฬา','ทีม 3 คน','ผู้ชนะคู่ที่ 33 – ผู้ชนะคู่ที่ 34','ม.ปลาย ชาย','ชิงชนะเลิศ','รอแข่งขัน','เอกสารกำหนดการแข่งขัน'),
(54,'รอระบุชนิดกีฬา','ทีม 3 คน','ผู้ชนะคู่ที่ 35 – ผู้ชนะคู่ที่ 36','ม.ปลาย หญิง','ชิงชนะเลิศ','รอแข่งขัน','เอกสารกำหนดการแข่งขัน');
